import React, { Component } from 'react';
import { Image } from 'semantic-ui-react';

export default class Map extends Component {
  render() {
    return <Image src="/img/map_view.png" />;
  }
}
