import React from 'react';
import { render } from 'react-dom';
// import { BrowserRouter } from 'react-router-dom';
// import routes from './routes';
import App from './App.js';

// render(<BrowserRouter routes={routes} />, document.getElementById('root'));
render(<App />, document.getElementById('root'));

// import ReactDOM from 'react-dom';
// import App from './App';

// ReactDOM.render(
//   <App />,
//   document.getElementById('root')
// );
